using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Globalization;
using System.Text.Json;

namespace Ecomads.WebApplication.Services.Wb;

public sealed class WbApiException : Exception
{
    public HttpStatusCode StatusCode { get; }
    public TimeSpan? RetryAfter { get; }

    public WbApiException(HttpStatusCode statusCode, TimeSpan? retryAfter = null)
        : base($"Wildberries API вернул HTTP {(int)statusCode}.")
    {
        StatusCode = statusCode;
        RetryAfter = retryAfter;
    }
}

public sealed record WbCampaignInfo(
    long Id,
    string Name,
    int Status,
    string? PaymentType,
    IReadOnlyList<long> NomenclatureIds,
    DateTime? CreatedAtUtc = null,
    DateTime? StartedAtUtc = null,
    DateTime? DeletedAtUtc = null,
    DateTime? UpdatedAtUtc = null, string? BidType = null, IReadOnlyList<string>? TimestampIssues = null);

public sealed record WbNormQueryPair(long AdvertId, long NmId);

public interface IWbPromotionClient
{
    Task<JsonDocument> GetClusterSettingsAsync(string token, IReadOnlyList<WbNormQueryPair> pairs, bool minus,
        CancellationToken ct) => throw new NotSupportedException("Cluster settings unavailable");
    Task<IReadOnlyList<WbCampaignInfo>> GetCampaignsAsync(string token, CancellationToken cancellationToken);
    Task<JsonDocument> GetFullStatsAsync(string token, IReadOnlyList<long> campaignIds,
        DateOnly startDate, DateOnly endDate, CancellationToken cancellationToken);
    Task<JsonDocument> GetCostsAsync(string token, DateOnly startDate, DateOnly endDate,
        CancellationToken cancellationToken);
    Task<JsonDocument> GetNormQueryStatsAsync(string token, IReadOnlyList<WbNormQueryPair> pairs,
        DateOnly startDate, DateOnly endDate, CancellationToken cancellationToken);
}

public sealed class WbPromotionClient(HttpClient httpClient, TimeProvider? clock = null) : IWbPromotionClient
{
    public async Task<JsonDocument> GetClusterSettingsAsync(string token, IReadOnlyList<WbNormQueryPair> pairs,
        bool minus, CancellationToken ct)
    {
        if (pairs.Count is < 1 or > 100) throw new ArgumentException("Настройки кластеров: от 1 до 100 пар.");
        using var request = new HttpRequestMessage(HttpMethod.Post, minus ? "/adv/v0/normquery/get-minus" : "/adv/v0/normquery/get-bids");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Content = JsonContent.Create(new { items = pairs.Select(x => new { advert_id = x.AdvertId, nm_id = x.NmId }).ToArray() });
        using var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        if (!response.IsSuccessStatusCode) throw new WbApiException(response.StatusCode, GetRetryAfter(response, (clock ?? TimeProvider.System).GetUtcNow()));
        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        var document = await JsonDocument.ParseAsync(stream, cancellationToken: ct);
        if (document.RootElement.ValueKind != JsonValueKind.Object || !document.RootElement.TryGetProperty(minus ? "items" : "bids", out var items) || items.ValueKind != JsonValueKind.Array)
        {
            document.Dispose();
            throw new JsonException("Неизвестный формат настроек кластеров WB.");
        }
        return document;
    }
    public async Task<JsonDocument> GetCostsAsync(string token, DateOnly startDate, DateOnly endDate,
        CancellationToken cancellationToken)
    {
        if (endDate < startDate || endDate.DayNumber - startDate.DayNumber > 30)
            throw new ArgumentException("История затрат WB: период от 1 до 31 дня.");
        using var request = new HttpRequestMessage(HttpMethod.Get,
            $"/adv/v1/upd?from={startDate:yyyy-MM-dd}&to={endDate:yyyy-MM-dd}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead,
            cancellationToken);
        if (!response.IsSuccessStatusCode) throw new WbApiException(response.StatusCode, GetRetryAfter(response, (clock ?? TimeProvider.System).GetUtcNow()));
        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
        if (document.RootElement.ValueKind != JsonValueKind.Array)
        {
            document.Dispose();
            throw new JsonException("История затрат WB имеет неожиданный формат.");
        }
        return document;
    }

    public async Task<JsonDocument> GetNormQueryStatsAsync(string token, IReadOnlyList<WbNormQueryPair> pairs,
        DateOnly startDate, DateOnly endDate, CancellationToken cancellationToken)
    {
        if (pairs.Count is < 1 or > 100 || endDate < startDate || endDate.DayNumber - startDate.DayNumber > 6)
        {
            throw new ArgumentException("Статистика кластеров WB: от 1 до 100 пар и не более 7 дней.");
        }

        using var request = new HttpRequestMessage(HttpMethod.Post, "/adv/v1/normquery/stats");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Content = JsonContent.Create(new
        {
            from = startDate.ToString("yyyy-MM-dd"),
            to = endDate.ToString("yyyy-MM-dd"),
            items = pairs.Select(pair => new { advertId = pair.AdvertId, nmId = pair.NmId }).ToArray()
        });
        using var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
        if (!response.IsSuccessStatusCode) throw new WbApiException(response.StatusCode, GetRetryAfter(response, (clock ?? TimeProvider.System).GetUtcNow()));
        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
        if (document.RootElement.ValueKind != JsonValueKind.Object || !document.RootElement.TryGetProperty("items", out var items) || items.ValueKind != JsonValueKind.Array)
        {
            document.Dispose();
            throw new JsonException("Статистика кластеров WB имеет неожиданный формат.");
        }
        return document;
    }

    public async Task<JsonDocument> GetFullStatsAsync(string token, IReadOnlyList<long> campaignIds,
        DateOnly startDate, DateOnly endDate, CancellationToken cancellationToken)
    {
        if (campaignIds.Count is < 1 or > 50 || endDate < startDate || endDate.DayNumber - startDate.DayNumber > 30)
        {
            throw new ArgumentException("Статистика WB: от 1 до 50 кампаний и не более 31 дня.");
        }

        var ids = string.Join(",", campaignIds);
        var path = $"/adv/v3/fullstats?ids={ids}&beginDate={startDate:yyyy-MM-dd}&endDate={endDate:yyyy-MM-dd}";
        using var request = new HttpRequestMessage(HttpMethod.Get, path);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            throw new WbApiException(response.StatusCode, GetRetryAfter(response, (clock ?? TimeProvider.System).GetUtcNow()));
        }
        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
        // WB sometimes returns HTTP 200 with JSON null. Keep it distinct from an empty
        // array so the importer can retry every requested campaign without confirming zeroes.
        if (document.RootElement.ValueKind is not (JsonValueKind.Array or JsonValueKind.Null))
        {
            var shape = document.RootElement.ValueKind == JsonValueKind.Object
                ? "object fields: " + string.Join(", ", document.RootElement.EnumerateObject()
                    .Select(property => property.Name).Take(12))
                : document.RootElement.ValueKind.ToString();
            document.Dispose();
            throw new JsonException($"Статистика WB имеет неожиданный формат ({shape}).");
        }
        return document;
    }

    public async Task<IReadOnlyList<WbCampaignInfo>> GetCampaignsAsync(string token, CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/advert/v2/adverts");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            throw new WbApiException(response.StatusCode, GetRetryAfter(response, (clock ?? TimeProvider.System).GetUtcNow()));
        }

        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        using var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
        return ReadCampaigns(document.RootElement);
    }

    public static IReadOnlyList<WbCampaignInfo> ReadCampaigns(JsonElement root)
    {
        try { return ParseCampaigns(root); }
        catch (Exception error) when (error is InvalidOperationException or KeyNotFoundException or FormatException or OverflowException)
        { throw new JsonException("Список кампаний WB содержит некорректные обязательные поля.", error); }
    }

    private static IReadOnlyList<WbCampaignInfo> ParseCampaigns(JsonElement root)
    {
        if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty("adverts", out var adverts) || adverts.ValueKind != JsonValueKind.Array)
        {
            throw new JsonException("В ответе Wildberries отсутствует массив adverts.");
        }

        var result = new List<WbCampaignInfo>(adverts.GetArrayLength());
        foreach (var advert in adverts.EnumerateArray())
        {
            var id = advert.GetProperty("id").GetInt64();
            var status = advert.GetProperty("status").GetInt32();
            var settings = advert.GetProperty("settings");
            var name = settings.GetProperty("name").GetString() ?? id.ToString();
            var paymentType = settings.TryGetProperty("payment_type", out var payment)
                ? payment.GetString()
                : null;
            var nms = new List<long>();
            if (advert.TryGetProperty("nm_settings", out var nmSettings) && nmSettings.ValueKind == JsonValueKind.Array)
            {
                foreach (var nm in nmSettings.EnumerateArray())
                {
                    if (nm.TryGetProperty("nm_id", out var nmId) && nmId.TryGetInt64(out var value))
                    {
                        nms.Add(value);
                    }
                }
            }
            var timestampIssues = new List<string>();
            DateTime? Timestamp(string property)
            {
                if (!advert.TryGetProperty("timestamps", out var timestamps) || timestamps.ValueKind != JsonValueKind.Object ||
                    !timestamps.TryGetProperty(property, out var value) || value.ValueKind == JsonValueKind.Null) return null;
                if (value.ValueKind == JsonValueKind.String && WbDates.TryInstant(value.GetString(), out var parsed)) return parsed;
                var issue = $"campaign {id}, timestamp {property}: ambiguous_time";
                timestampIssues.Add(issue); WbIngestionContext.Current?.Reject(issue); return null;
            }
            result.Add(new WbCampaignInfo(id, name, status, paymentType, nms,
                Timestamp("created"), Timestamp("started"), Timestamp("deleted"), Timestamp("updated"),
                advert.TryGetProperty("bid_type", out var bidType) ? bidType.GetString() : null, timestampIssues));
        }

        if (result.Select(x => x.Id).Distinct().Count() != result.Count) throw new JsonException("Повторный ID кампании WB.");
        return result;
    }

    internal static TimeSpan? GetRetryAfter(HttpResponseMessage response, DateTimeOffset? now = null)
    {
        TimeSpan? custom = null;
        if (response.Headers.TryGetValues("X-Ratelimit-Retry", out var values) &&
            double.TryParse(values.FirstOrDefault(), NumberStyles.Float, CultureInfo.InvariantCulture, out var seconds) &&
            seconds > 0 && seconds < TimeSpan.MaxValue.TotalSeconds)
            custom = TimeSpan.FromSeconds(seconds);
        var header = response.Headers.RetryAfter;
        if (header?.Delta is { } delta) return custom > delta ? custom : delta;
        if (header?.Date is { } date)
        {
            var remaining = date - (now ?? TimeProvider.System.GetUtcNow());
            return custom > remaining ? custom : remaining > TimeSpan.Zero ? remaining : TimeSpan.Zero;
        }
        return custom;
    }
}
