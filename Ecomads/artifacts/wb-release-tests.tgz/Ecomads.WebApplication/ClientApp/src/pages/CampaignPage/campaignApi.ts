import { z } from 'zod';
import { httpClient } from '../../shared/api/httpClient';
import { loadedPeriodsResponseSchema, projectsResponseSchema } from '../../shared/api/apiSchemas';
import type { DashboardFilters } from '../DashboardPage/dashboardApi';

const nomenclatureSchema = z.object({
  nomenclatureId: z.string(), name: z.string(), impressions: z.number(), clicks: z.number(),
  carts: z.number(), orders: z.number(), spend: z.number(), revenue: z.number(),
  ctr: z.number().nullable(), cr: z.number().nullable(), cpc: z.number().nullable(), cpo: z.number().nullable()
});
export type NomenclatureStatistics = z.infer<typeof nomenclatureSchema>;

export const wbClusterRowSchema = z.object({
  nomenclatureId: z.string(), nomenclatureName: z.string(), clusterName: z.string(),
  spend: z.number(), views: z.number().int().nullable(), clicks: z.number().int().nullable(),
  carts: z.number().int().nullable(), orders: z.number().int().nullable(), cpc: z.number().nullable(),
  assessment: z.string(), orderedProducts: z.number().int().nullable(),
  averageOrderedUnitPrice: z.number().nullable(), estimatedOrderSum: z.number().nullable(),
  estimatedDrr: z.number().nullable(), estimateStatus: z.enum(['complete', 'preliminary', 'unavailable']),
  estimateReason: z.string().nullable()
});
const wbClustersSchema = z.object({ isWbConnected: z.boolean(), isPeriodComplete: z.boolean(), rows: z.array(wbClusterRowSchema),
  storeNormVersion: z.number().int(), campaignNormVersion: z.number().int() });
export type WbClusterRow = z.infer<typeof wbClusterRowSchema>;

const spendTrendSchema = z.object({
  endDate: z.string(), status: z.enum(['insufficient', 'no_baseline', 'increase', 'decrease', 'normal']),
  loadedDays: z.number().int(), yesterdaySpend: z.number().nullable(),
  baselineDailySpend: z.number().nullable(), changePercent: z.number().nullable(),
  thresholdPercent: z.number(), storeNormVersion: z.number().int(), campaignNormVersion: z.number().int()
});

function queryString(filters: DashboardFilters): string {
  const query = new URLSearchParams();
  if (filters.startDate) query.set('startDate', filters.startDate);
  if (filters.endDate) query.set('endDate', filters.endDate);
  return query.size ? `?${query.toString()}` : '';
}

export async function getCampaignSummary(campaignId: string, filters: DashboardFilters = {}) {
  const campaigns = projectsResponseSchema.parse(await httpClient<unknown>(`/api/projects${queryString(filters)}`));
  return campaigns.find((campaign) => campaign.id.toLowerCase() === campaignId.toLowerCase()) ?? null;
}

export async function getCampaignPeriods() {
  return loadedPeriodsResponseSchema.parse(await httpClient<unknown>('/api/statistics/periods'));
}

export async function getNomenclatureStatistics(campaignId: string, filters: DashboardFilters = {}) {
  return nomenclatureSchema.array().parse(await httpClient<unknown>(
    `/api/statistics/nomenclatures/${encodeURIComponent(campaignId)}${queryString(filters)}`));
}

export async function getWbClusters(campaignId: string, filters: DashboardFilters = {}) {
  return wbClustersSchema.parse(await httpClient<unknown>(
    `/api/wb/campaigns/${encodeURIComponent(campaignId)}/clusters${queryString(filters)}`));
}

const jamRowSchema = z.object({
  nomenclatureId: z.string(), nomenclatureName: z.string(), searchText: z.string(),
  frequency: z.number().nullable(), weekFrequency: z.number().nullable(),
  averagePosition: z.number().nullable(), medianPosition: z.number().nullable(),
  openCard: z.number().nullable(), addToCart: z.number().nullable(), orders: z.number().nullable(),
  matchingLoadedAdCluster: z.boolean()
});
const jamResponseSchema = z.object({
  jamStatus: z.enum(['unknown', 'active', 'access_denied', 'payment_required']),
  jamCheckedAtUtc: z.string().nullable(), startDate: z.string(), endDate: z.string(),
  articleCount: z.number().int(), articlesWithQueries: z.number().int(), rows: z.array(jamRowSchema),
  reportStatus: z.enum(['complete', 'empty', 'partial', 'legacy', 'not_loaded', 'access_denied']),
  checkedArticleCount: z.number().int(), emptyArticleCount: z.number().int(),
  availableReports: z.array(z.object({ startDate: z.string(), endDate: z.string(), loadedAtUtc: z.string() }))
});
export type WbJamRow = z.infer<typeof jamRowSchema>;
export type WbJamResponse = z.infer<typeof jamResponseSchema>;

export async function getWbJam(campaignId: string, filters: DashboardFilters = {}): Promise<WbJamResponse> {
  return jamResponseSchema.parse(await httpClient<unknown>(
    `/api/wb/campaigns/${encodeURIComponent(campaignId)}/jam${queryString(filters)}`));
}

export async function getWbSpendTrend(campaignId: string, endDate?: string) {
  const query = endDate ? `?endDate=${encodeURIComponent(endDate)}` : '';
  return spendTrendSchema.parse(await httpClient<unknown>(
    `/api/wb/campaigns/${encodeURIComponent(campaignId)}/spend-trend${query}`));
}
