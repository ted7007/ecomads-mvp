import { httpClient } from '../../shared/api/httpClient';
import { z } from 'zod';
import { loadedPeriodsResponseSchema, projectsResponseSchema } from '../../shared/api/apiSchemas';
import type { LoadedPeriod, ProjectDashboard } from '../../shared/api/apiTypes';

export type DashboardFilters = {
  startDate?: string;
  endDate?: string;
};

const dailyPointSchema = z.object({
  date: z.string(), isPreliminary: z.boolean(), spend: z.number().nullable(), revenue: z.number().nullable(),
  clicks: z.number().int().nullable(), impressions: z.number().int().nullable(),
  orders: z.number().int().nullable(), drr: z.number().nullable(), ctr: z.number().nullable(),
  totalOrderSum: z.number().nullable().optional(), totalOrderCount: z.number().int().nullable().optional(),
  totalDrr: z.number().nullable().optional(),
  loadedCampaigns: z.number().int(), expectedCampaigns: z.number().int()
});
export type DailyPoint = z.infer<typeof dailyPointSchema>;

const coverageSchema = z.object({
  days: z.array(z.object({ date: z.string(), spend: z.number().nullable(), orders: z.number().nullable(),
    drr: z.number().nullable(), checkedCampaigns: z.number().int(), expectedCampaigns: z.number().int(),
    checkedStores: z.number().int(), expectedStores: z.number().int() })),
  confirmedDays: z.number().int(), drr: z.number().nullable(),
  status: z.enum(['complete', 'preliminary', 'unavailable']), reason: z.string().nullable(),
  lastCheckedAtUtc: z.string().nullable()
});
export type CoveragePeriod = z.infer<typeof coverageSchema>;

export async function getCoverage(filters: DashboardFilters, campaignId?: string): Promise<CoveragePeriod> {
  const query = new URLSearchParams();
  if (filters.startDate) query.set('startDate', filters.startDate);
  if (filters.endDate) query.set('endDate', filters.endDate);
  if (campaignId) query.set('campaignId', campaignId);
  return coverageSchema.parse(await httpClient<unknown>(`/api/statistics/coverage?${query}`));
}

export async function getDailySeries(filters: DashboardFilters, campaignId?: string): Promise<DailyPoint[]> {
  const query = new URLSearchParams();
  if (filters.startDate) query.set('startDate', filters.startDate);
  if (filters.endDate) query.set('endDate', filters.endDate);
  if (campaignId) query.set('campaignId', campaignId);
  return dailyPointSchema.array().parse(await httpClient<unknown>(`/api/statistics/daily?${query}`));
}

export async function getCampaigns(filters: DashboardFilters = {}): Promise<ProjectDashboard[]> {
  const query = new URLSearchParams();

  if (filters.startDate) {
    query.set('startDate', filters.startDate);
  }

  if (filters.endDate) {
    query.set('endDate', filters.endDate);
  }

  const suffix = query.toString() ? `?${query.toString()}` : '';
  const response = await httpClient<unknown>(`/api/projects${suffix}`);

  return projectsResponseSchema.parse(response);
}

export async function getLoadedPeriods(): Promise<LoadedPeriod[]> {
  const response = await httpClient<unknown>('/api/statistics/periods');
  return loadedPeriodsResponseSchema.parse(response);
}
