using Microsoft.EntityFrameworkCore;
using Ecomads.WebApplication.Data.Models;

namespace Ecomads.WebApplication.Data;

public class EcomadsDbContext : DbContext
{
    public DbSet<WbResponseSnapshot> WbResponseSnapshots { get; set; }
    public DbSet<WbSourceQuality> WbSourceQualities { get; set; }
    public DbSet<WbCostObservation> WbCostObservations { get; set; }
    public DbSet<WbIngestionDecision> WbIngestionDecisions { get; set; }
    public EcomadsDbContext(DbContextOptions<EcomadsDbContext> options) : base(options) { }

    public DbSet<Seller> Sellers { get; set; }
    public DbSet<Store> Stores { get; set; }
    public DbSet<Campaign> Campaigns { get; set; }
    public DbSet<Nomenclature> Nomenclatures { get; set; }
    public DbSet<CampaignNomenclatureStatistics> CampaignNomenclatureStatistics { get; set; }
    public DbSet<CampaignStatistics> CampaignStatistics { get; set; }
    public DbSet<DemoFeedback> DemoFeedbacks { get; set; }
    public DbSet<WbSyncJob> WbSyncJobs { get; set; }
    public DbSet<WbRefreshSchedule> WbRefreshSchedules { get; set; }
    public DbSet<WbSyncJobEvent> WbSyncJobEvents { get; set; }
    public DbSet<WbStoreDailyOrders> WbStoreDailyOrders { get; set; }
    public DbSet<WbStoreDailySpend> WbStoreDailySpends { get; set; }
    public DbSet<WbClusterStatistic> WbClusterStatistics { get; set; }
    public DbSet<WbJamSearchQuery> WbJamSearchQueries { get; set; }
    public DbSet<WbMethodSlot> WbMethodSlots { get; set; }
    public DbSet<WbCampaignDailyCheck> WbCampaignDailyChecks { get; set; }
    public DbSet<WbJamArticleCheck> WbJamArticleChecks { get; set; }
    public DbSet<WbStoreNorms> WbStoreNorms { get; set; }
    public DbSet<WbCampaignNorms> WbCampaignNorms { get; set; }
    public DbSet<WbNormRevision> WbNormRevisions { get; set; }
    public DbSet<WbRecommendationDecision> WbRecommendationDecisions { get; set; }
    public DbSet<WbRecommendationRun> WbRecommendationRuns { get; set; }
    public DbSet<WbAdvertisingSettings> WbAdvertisingSettings { get; set; }
    public DbSet<WbSnapshotDecision> WbSnapshotDecisions { get; set; }
    public DbSet<WbArticleNorm> WbArticleNorms { get; set; }
    public DbSet<WbArticleObservation> WbArticleObservations { get; set; }
    public DbSet<TelegramLinkCode> TelegramLinkCodes { get; set; }
    public DbSet<TelegramChat> TelegramChats { get; set; }
    public DbSet<TelegramDelivery> TelegramDeliveries { get; set; }
    public DbSet<TelegramBotState> TelegramBotStates { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<WbResponseSnapshot>(e => {
            e.ToTable("wb_response_snapshots"); e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.StoreId, x.RequestedAtUtc });
            e.HasIndex(x => new { x.JobId, x.Page });
            e.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbSourceQuality>(e => {
            e.ToTable("wb_source_quality"); e.HasKey(x => new { x.StoreId, x.Source, x.Entity, x.StartDate, x.EndDate });
            e.HasIndex(x => x.SnapshotId); e.HasIndex(x => x.AcceptedSnapshotId);
            e.Property(x => x.PreviousValue).HasPrecision(18, 2); e.Property(x => x.ProposedValue).HasPrecision(18, 2);
            e.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbCostObservation>(e => {
            e.ToTable("wb_cost_observations"); e.HasKey(x => new { x.SnapshotId, x.Ordinal });
            e.Property(x => x.Amount).HasPrecision(18, 2);
            e.HasIndex(x => new { x.StoreId, x.MoscowDate });
            e.HasOne<WbResponseSnapshot>().WithMany().HasForeignKey(x => x.SnapshotId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbIngestionDecision>(e => {
            e.ToTable("wb_ingestion_decisions"); e.HasKey(x => x.Id);
            e.Property(x => x.PreviousValue).HasPrecision(18, 2); e.Property(x => x.AcceptedValue).HasPrecision(18, 2);
            e.HasIndex(x => new { x.StoreId, x.Date });
        });
        modelBuilder.Entity<WbAdvertisingSettings>(entity =>
        {
            entity.ToTable("wb_advertising_settings");
            entity.HasKey(x => x.CampaignId);
            entity.Property(x => x.PayloadJson).HasColumnType("jsonb");
            entity.HasOne<Campaign>().WithMany().HasForeignKey(x => x.CampaignId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbSnapshotDecision>(entity =>
        {
            entity.ToTable("wb_snapshot_decisions");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => new { x.RunId, x.EvaluationId, x.RuleId, x.CreatedAtUtc });
            entity.HasOne<WbRecommendationRun>().WithMany().HasForeignKey(x => x.RunId).OnDelete(DeleteBehavior.Restrict);
        });
        modelBuilder.Entity<WbRecommendationRun>(entity =>
        {
            entity.ToTable("wb_recommendation_runs");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Fingerprint).HasMaxLength(64);
            entity.Property(x => x.SnapshotJson).HasColumnType("jsonb");
            entity.HasIndex(x => new { x.CampaignId, x.StartDate, x.EndDate, x.Fingerprint }).IsUnique();
            entity.HasIndex(x => new { x.StoreId, x.CalculatedAtUtc });
            entity.HasOne<Campaign>().WithMany().HasForeignKey(x => x.CampaignId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Seller>().WithMany().HasForeignKey(x => x.SellerId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbArticleNorm>(entity =>
        {
            entity.ToTable("wb_article_norms");
            entity.HasKey(x => new { x.CampaignId, x.NomenclatureId });
            entity.Property(x => x.TargetDrr).HasColumnType("decimal(8,2)");
            entity.HasOne<Campaign>().WithMany().HasForeignKey(x => x.CampaignId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Nomenclature>().WithMany().HasForeignKey(x => x.NomenclatureId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbArticleObservation>(entity =>
        {
            entity.ToTable("wb_article_observations");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Revenue).HasColumnType("decimal(18,2)");
            entity.HasIndex(x => new { x.CampaignId, x.NomenclatureId, x.Date, x.ObservedAtUtc });
            entity.HasOne<Campaign>().WithMany().HasForeignKey(x => x.CampaignId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Nomenclature>().WithMany().HasForeignKey(x => x.NomenclatureId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<Seller>(entity =>
        {
            entity.ToTable("sellers");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name).IsRequired().HasMaxLength(255).HasColumnName("name");
            entity.Property(e => e.Email).IsRequired().HasMaxLength(255).HasColumnName("email");
            entity.Property(e => e.PasswordHash).IsRequired().HasMaxLength(255).HasColumnName("password_hash");
            entity.Property(e => e.Phone).HasMaxLength(50).HasColumnName("phone");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.LastLoginAt).HasColumnName("last_login_at");
            entity.Property(e => e.IsDemoUser).HasColumnName("is_demo_user").HasDefaultValue(false);
            entity.Property(e => e.AccessType).HasColumnName("access_type").HasDefaultValue(UserAccessType.Regular);
            entity.Property(e => e.DemoStatus).HasColumnName("demo_status").HasDefaultValue(DemoAccessStatus.None);
            entity.Property(e => e.DemoStartedAtUtc).HasColumnName("demo_started_at_utc");
            entity.Property(e => e.DemoExpiresAtUtc).HasColumnName("demo_expires_at_utc");
            entity.Property(e => e.DemoFeedbackSubmittedAtUtc).HasColumnName("demo_feedback_submitted_at_utc");
            entity.Property(e => e.MvpAccessGrantedAtUtc).HasColumnName("mvp_access_granted_at_utc");
            
            // Email должен быть уникальным
            entity.HasIndex(e => e.Email).IsUnique();
        });

        modelBuilder.Entity<DemoFeedback>(entity =>
        {
            entity.ToTable("demo_feedbacks");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.GeneralComment).IsRequired().HasColumnName("general_comment").HasColumnType("text");
            entity.Property(e => e.AnswersJson).IsRequired().HasColumnName("answers_json").HasColumnType("jsonb");
            entity.Property(e => e.CreatedAtUtc).HasColumnName("created_at_utc");

            entity.HasOne<Seller>()
                .WithOne()
                .HasForeignKey<DemoFeedback>(e => e.UserId)
                .HasConstraintName("FK_demo_feedbacks_sellers_user_id")
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => e.UserId).IsUnique();
        });



        modelBuilder.Entity<Store>(entity =>
        {
            entity.ToTable("stores");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name).IsRequired().HasMaxLength(255).HasColumnName("name");
            entity.Property(e => e.Description).HasMaxLength(255).HasColumnName("description");
            entity.Property(e => e.Marketplace).HasMaxLength(50).HasColumnName("marketplace").HasDefaultValue("Wildberries");
            entity.Property(e => e.ExternalId).HasMaxLength(100).HasColumnName("external_id");
            entity.Property(e => e.ApiKey).HasColumnType("text").HasColumnName("api_key");
            entity.Property(e => e.TokenLastFour).HasMaxLength(4).HasColumnName("token_last_four");
            entity.Property(e => e.TokenExpiresAtUtc).HasColumnName("token_expires_at_utc");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.LastSyncAt).HasColumnName("last_sync_at");
            entity.Property(e => e.CampaignsRefreshedAtUtc).HasColumnName("campaigns_refreshed_at_utc");
            entity.Property(e => e.JamStatus).HasColumnName("jam_status").HasMaxLength(32).HasDefaultValue("unknown");
            entity.Property(e => e.JamCheckedAtUtc).HasColumnName("jam_checked_at_utc");
            entity.Property(e => e.AutoRefreshEnabled).HasColumnName("auto_refresh_enabled").HasDefaultValue(true);
            entity.Property(e => e.AutoRefreshBlocked).HasColumnName("auto_refresh_blocked").HasDefaultValue(false);
            entity.Property(e => e.AutoHistoryStartedAtUtc).HasColumnName("auto_history_started_at_utc");
            entity.Property(e => e.SellerId).HasColumnName("seller_id");
            entity.HasIndex(e => new { e.Marketplace, e.ExternalId })
                .IsUnique()
                .HasFilter("external_id IS NOT NULL");
            
            entity.HasOne(e => e.Seller)
                .WithMany(s => s.Stores)
                .HasForeignKey(e => e.SellerId)
                .HasConstraintName("FK_stores_sellers_seller_id")
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Campaign>(entity =>
        {
            entity.ToTable("campaigns");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name).IsRequired().HasMaxLength(255).HasColumnName("name");
            entity.Property(e => e.WbCampaignId).IsRequired().HasMaxLength(50).HasColumnName("wb_campaign_id");
            entity.Property(e => e.IsActive).HasColumnName("is_active").HasDefaultValue(true);
            entity.Property(e => e.WbStatus).HasColumnName("wb_status");
            entity.Property(e => e.LastSeenAt).HasColumnName("last_seen_at");
            entity.Property(e => e.WbCreatedAtUtc).HasColumnName("wb_created_at_utc");
            entity.Property(e => e.WbStartedAtUtc).HasColumnName("wb_started_at_utc");
            entity.Property(e => e.WbDeletedAtUtc).HasColumnName("wb_deleted_at_utc");
            entity.Property(e => e.WbUpdatedAtUtc).HasColumnName("wb_updated_at_utc");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.StoreId).HasColumnName("store_id");
            entity.HasOne(e => e.Store)
                .WithMany(s => s.Campaigns)
                .HasForeignKey(e => e.StoreId)
                .HasConstraintName("FK_campaigns_stores_store_id")
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(e => new { e.StoreId, e.WbCampaignId }).IsUnique();
        });

        modelBuilder.Entity<WbRefreshSchedule>(entity =>
        {
            entity.ToTable("wb_refresh_schedules");
            entity.HasKey(x => new { x.StoreId, x.Task });
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.Task).HasColumnName("task").HasMaxLength(32);
            entity.Property(x => x.RequestedSlotUtc).HasColumnName("requested_slot_utc");
            entity.Property(x => x.PlannedSlotUtc).HasColumnName("planned_slot_utc");
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbSyncJob>(entity =>
        {
            entity.ToTable("wb_sync_jobs");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.StoreId).HasColumnName("store_id");
            entity.Property(e => e.RunId).HasColumnName("run_id");
            entity.Property(e => e.StartDate).HasColumnName("start_date");
            entity.Property(e => e.EndDate).HasColumnName("end_date");
            entity.Property(e => e.CampaignIdsJson).HasColumnName("campaign_ids_json").HasColumnType("jsonb");
            entity.Property(e => e.PairIdsJson).HasColumnName("pair_ids_json").HasColumnType("jsonb");
            entity.Property(e => e.Kind).HasColumnName("kind").HasMaxLength(32).HasDefaultValue("fullstats");
            entity.Property(e => e.NextCampaignOffset).HasColumnName("next_campaign_offset");
            entity.Property(e => e.AttemptCount).HasColumnName("attempt_count");
            entity.Property(e => e.Status).HasColumnName("status").HasMaxLength(32);
            entity.Property(e => e.Stage).HasColumnName("stage").HasMaxLength(40).HasDefaultValue("queued");
            entity.Property(e => e.WaitReason).HasColumnName("wait_reason").HasMaxLength(80);
            entity.Property(e => e.RetriedFromJobId).HasColumnName("retried_from_job_id");
            entity.Property(e => e.CreatedAtUtc).HasColumnName("created_at_utc");
            entity.Property(e => e.StartedAtUtc).HasColumnName("started_at_utc");
            entity.Property(e => e.CompletedAtUtc).HasColumnName("completed_at_utc");
            entity.Property(e => e.UpdatedAtUtc).HasColumnName("updated_at_utc");
            entity.Property(e => e.NextAttemptAtUtc).HasColumnName("next_attempt_at_utc");
            entity.Property(e => e.LastRequestAtUtc).HasColumnName("last_request_at_utc");
            entity.Property(e => e.PauseRequestedAtUtc).HasColumnName("pause_requested_at_utc");
            entity.Property(e => e.ErrorCode).HasColumnName("error_code").HasMaxLength(80);
            entity.Property(e => e.ImportedRows).HasColumnName("imported_rows");
            entity.Property(e => e.ItemsWithData).HasColumnName("items_with_data");
            entity.Property(e => e.ItemsWithoutData).HasColumnName("items_without_data");
            entity.HasIndex(e => new { e.StoreId, e.Status, e.NextAttemptAtUtc });
            entity.HasIndex(e => new { e.StoreId, e.Kind }).IsUnique().HasFilter("status IN ('pending', 'running')");
            entity.HasIndex(e => new { e.StoreId, e.RunId });
            entity.HasOne<Store>().WithMany().HasForeignKey(e => e.StoreId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbMethodSlot>(entity =>
        {
            entity.ToTable("wb_method_slots");
            entity.HasKey(x => new { x.StoreId, x.Method });
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.Method).HasColumnName("method").HasMaxLength(40);
            entity.Property(x => x.LastRequestAtUtc).HasColumnName("last_request_at_utc");
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbCampaignDailyCheck>(entity =>
        {
            entity.ToTable("wb_campaign_daily_checks");
            entity.HasKey(x => new { x.CampaignId, x.Date });
            entity.Property(x => x.CampaignId).HasColumnName("campaign_id");
            entity.Property(x => x.Date).HasColumnName("date");
            entity.Property(x => x.JobId).HasColumnName("job_id");
            entity.Property(x => x.CheckedAtUtc).HasColumnName("checked_at_utc");
            entity.Property(x => x.LastAttemptAtUtc).HasColumnName("last_attempt_at_utc");
            entity.Property(x => x.LastAttemptResult).HasColumnName("last_attempt_result").HasMaxLength(24);
            entity.Property(x => x.Result).HasColumnName("result").HasMaxLength(24);
            entity.Property(x => x.Spend).HasColumnName("spend").HasColumnType("decimal(18,2)");
            entity.HasOne<Campaign>().WithMany().HasForeignKey(x => x.CampaignId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<WbJamArticleCheck>(entity =>
        {
            entity.ToTable("wb_jam_article_checks");
            entity.HasKey(x => new { x.StoreId, x.NomenclatureId, x.StartDate, x.EndDate });
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.NomenclatureId).HasColumnName("nomenclature_id");
            entity.Property(x => x.StartDate).HasColumnName("start_date");
            entity.Property(x => x.EndDate).HasColumnName("end_date");
            entity.Property(x => x.JobId).HasColumnName("job_id");
            entity.Property(x => x.CheckedAtUtc).HasColumnName("checked_at_utc");
            entity.Property(x => x.HasData).HasColumnName("has_data");
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Nomenclature>().WithMany().HasForeignKey(x => x.NomenclatureId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbSyncJobEvent>(entity =>
        {
            entity.ToTable("wb_sync_job_events");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            entity.Property(e => e.JobId).HasColumnName("job_id");
            entity.Property(e => e.OccurredAtUtc).HasColumnName("occurred_at_utc");
            entity.Property(e => e.Stage).HasColumnName("stage").HasMaxLength(40);
            entity.Property(e => e.ErrorCode).HasColumnName("error_code").HasMaxLength(80);
            entity.Property(e => e.ProcessedCount).HasColumnName("processed_count");
            entity.Property(e => e.AttemptNumber).HasColumnName("attempt_number");
            entity.HasIndex(e => new { e.JobId, e.OccurredAtUtc });
            entity.HasOne<WbSyncJob>().WithMany().HasForeignKey(e => e.JobId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbClusterStatistic>(entity =>
        {
            entity.ToTable("wb_cluster_statistics");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CampaignId).HasColumnName("campaign_id");
            entity.Property(e => e.NomenclatureId).HasColumnName("nomenclature_id");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.ClusterName).HasColumnName("cluster_name").HasMaxLength(500);
            entity.Property(e => e.Spend).HasColumnName("spend").HasColumnType("decimal(18,2)");
            entity.Property(e => e.Views).HasColumnName("views");
            entity.Property(e => e.Clicks).HasColumnName("clicks");
            entity.Property(e => e.Carts).HasColumnName("carts");
            entity.Property(e => e.Orders).HasColumnName("orders");
            entity.Property(e => e.OrderedProducts).HasColumnName("ordered_products");
            entity.Property(e => e.AveragePosition).HasColumnName("average_position").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Cpc).HasColumnName("cpc").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Cpm).HasColumnName("cpm").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Ctr).HasColumnName("ctr").HasColumnType("decimal(18,4)");
            entity.HasOne<Campaign>().WithMany().HasForeignKey(e => e.CampaignId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Nomenclature>().WithMany().HasForeignKey(e => e.NomenclatureId).OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(e => new { e.CampaignId, e.NomenclatureId, e.Date, e.ClusterName }).IsUnique();
        });

        modelBuilder.Entity<WbJamSearchQuery>(entity =>
        {
            entity.ToTable("wb_jam_search_queries");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).HasColumnName("id");
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.NomenclatureId).HasColumnName("nomenclature_id");
            entity.Property(x => x.StartDate).HasColumnName("start_date");
            entity.Property(x => x.EndDate).HasColumnName("end_date");
            entity.Property(x => x.SearchText).HasColumnName("search_text").HasMaxLength(500);
            entity.Property(x => x.Frequency).HasColumnName("frequency");
            entity.Property(x => x.WeekFrequency).HasColumnName("week_frequency");
            entity.Property(x => x.AveragePosition).HasColumnName("average_position").HasColumnType("decimal(18,4)");
            entity.Property(x => x.MedianPosition).HasColumnName("median_position").HasColumnType("decimal(18,4)");
            entity.Property(x => x.OpenCard).HasColumnName("open_card");
            entity.Property(x => x.AddToCart).HasColumnName("add_to_cart");
            entity.Property(x => x.Orders).HasColumnName("orders");
            entity.Property(x => x.LoadedAtUtc).HasColumnName("loaded_at_utc");
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Nomenclature>().WithMany().HasForeignKey(x => x.NomenclatureId).OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(x => new { x.StoreId, x.NomenclatureId, x.StartDate, x.EndDate, x.SearchText }).IsUnique();
        });

        modelBuilder.Entity<WbStoreDailyOrders>(entity =>
        {
            entity.ToTable("wb_store_daily_orders");
            entity.HasKey(x => new { x.StoreId, x.Date });
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.Date).HasColumnName("date");
            entity.Property(x => x.OrderCount).HasColumnName("order_count");
            entity.Property(x => x.OrderSum).HasColumnName("order_sum").HasColumnType("decimal(18,2)");
            entity.Property(x => x.OpenCount).HasColumnName("open_count");
            entity.Property(x => x.CartCount).HasColumnName("cart_count");
            entity.Property(x => x.BuyoutCount).HasColumnName("buyout_count");
            entity.Property(x => x.BuyoutSum).HasColumnName("buyout_sum").HasColumnType("decimal(18,2)");
            entity.Property(x => x.Source).HasColumnName("source").HasMaxLength(20);
            entity.Property(x => x.LoadedAtUtc).HasColumnName("loaded_at_utc");
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbStoreDailySpend>(entity =>
        {
            entity.ToTable("wb_store_daily_spend");
            entity.HasKey(x => new { x.StoreId, x.Date });
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.Date).HasColumnName("date");
            entity.Property(x => x.Spend).HasColumnName("spend").HasColumnType("decimal(18,2)");
            entity.Property(x => x.LoadedAtUtc).HasColumnName("loaded_at_utc");
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbStoreNorms>(entity =>
        {
            entity.ToTable("wb_store_norms");
            entity.HasKey(x => x.StoreId);
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.TargetDrr).HasColumnName("target_drr").HasColumnType("decimal(8,2)");
            entity.Property(x => x.MinCtr).HasColumnName("min_ctr").HasColumnType("decimal(8,2)").HasDefaultValue(3m);
            entity.Property(x => x.MinClicks).HasColumnName("min_clicks");
            entity.Property(x => x.MinSpend).HasColumnName("min_spend").HasColumnType("decimal(18,2)");
            entity.Property(x => x.MinOrders).HasColumnName("min_orders");
            entity.Property(x => x.DeviationPercent).HasColumnName("deviation_percent").HasColumnType("decimal(8,2)");
            entity.Property(x => x.Version).HasColumnName("version");
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");
            entity.HasOne<Store>().WithOne().HasForeignKey<WbStoreNorms>(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbCampaignNorms>(entity =>
        {
            entity.ToTable("wb_campaign_norms");
            entity.HasKey(x => x.CampaignId);
            entity.Property(x => x.CampaignId).HasColumnName("campaign_id");
            entity.Property(x => x.CustomName).HasColumnName("custom_name").HasMaxLength(255);
            entity.Property(x => x.Goal).HasColumnName("goal").HasMaxLength(255);
            entity.Property(x => x.TargetDrr).HasColumnName("target_drr").HasColumnType("decimal(8,2)");
            entity.Property(x => x.MinCtr).HasColumnName("min_ctr").HasColumnType("decimal(8,2)");
            entity.Property(x => x.MinClicks).HasColumnName("min_clicks");
            entity.Property(x => x.MinSpend).HasColumnName("min_spend").HasColumnType("decimal(18,2)");
            entity.Property(x => x.MinOrders).HasColumnName("min_orders");
            entity.Property(x => x.DeviationPercent).HasColumnName("deviation_percent").HasColumnType("decimal(8,2)");
            entity.Property(x => x.Version).HasColumnName("version");
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");
            entity.HasOne<Campaign>().WithOne().HasForeignKey<WbCampaignNorms>(x => x.CampaignId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbRecommendationDecision>(entity =>
        {
            entity.ToTable("wb_recommendation_decisions");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).HasColumnName("id");
            entity.Property(x => x.SellerId).HasColumnName("seller_id");
            entity.Property(x => x.RecommendationKey).HasColumnName("recommendation_key").HasMaxLength(512);
            entity.Property(x => x.StartDate).HasColumnName("start_date");
            entity.Property(x => x.EndDate).HasColumnName("end_date");
            entity.Property(x => x.Status).HasColumnName("status").HasMaxLength(32);
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");
            entity.HasIndex(x => new { x.SellerId, x.RecommendationKey, x.StartDate, x.EndDate }).IsUnique();
            entity.HasOne<Seller>().WithMany().HasForeignKey(x => x.SellerId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<WbNormRevision>(entity =>
        {
            entity.ToTable("wb_norm_revisions");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).HasColumnName("id");
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.CampaignId).HasColumnName("campaign_id");
            entity.Property(x => x.NomenclatureId).HasColumnName("nomenclature_id");
            entity.Property(x => x.Version).HasColumnName("version");
            entity.Property(x => x.SettingsJson).HasColumnName("settings_json").HasColumnType("jsonb");
            entity.Property(x => x.CreatedAtUtc).HasColumnName("created_at_utc");
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<Campaign>().WithMany().HasForeignKey(x => x.CampaignId).OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(x => new { x.StoreId, x.CampaignId, x.Version });
        });

        modelBuilder.Entity<TelegramLinkCode>(entity =>
        {
            entity.ToTable("telegram_link_codes");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).HasColumnName("id");
            entity.Property(x => x.SellerId).HasColumnName("seller_id");
            entity.Property(x => x.CodeHash).HasColumnName("code_hash").HasMaxLength(64);
            entity.Property(x => x.ExpiresAtUtc).HasColumnName("expires_at_utc");
            entity.Property(x => x.UsedAtUtc).HasColumnName("used_at_utc");
            entity.HasIndex(x => x.CodeHash).IsUnique();
            entity.HasOne<Seller>().WithMany().HasForeignKey(x => x.SellerId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<TelegramChat>(entity =>
        {
            entity.ToTable("telegram_chats");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).HasColumnName("id");
            entity.Property(x => x.SellerId).HasColumnName("seller_id");
            entity.Property(x => x.ChatId).HasColumnName("chat_id");
            entity.Property(x => x.DisplayName).HasColumnName("display_name").HasMaxLength(255);
            entity.Property(x => x.LinkedAtUtc).HasColumnName("linked_at_utc");
            entity.Property(x => x.IsActive).HasColumnName("is_active");
            entity.HasIndex(x => x.ChatId).IsUnique();
            entity.HasOne<Seller>().WithMany().HasForeignKey(x => x.SellerId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<TelegramDelivery>(entity =>
        {
            entity.ToTable("telegram_deliveries");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).HasColumnName("id");
            entity.Property(x => x.StoreId).HasColumnName("store_id");
            entity.Property(x => x.ChatId).HasColumnName("chat_id");
            entity.Property(x => x.ReportDate).HasColumnName("report_date");
            entity.Property(x => x.Status).HasColumnName("status").HasMaxLength(32);
            entity.Property(x => x.CreatedAtUtc).HasColumnName("created_at_utc");
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");
            entity.Property(x => x.ErrorCode).HasColumnName("error_code").HasMaxLength(80);
            entity.HasIndex(x => new { x.StoreId, x.ChatId, x.ReportDate }).IsUnique();
            entity.HasOne<Store>().WithMany().HasForeignKey(x => x.StoreId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<TelegramChat>().WithMany().HasForeignKey(x => x.ChatId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<TelegramBotState>(entity =>
        {
            entity.ToTable("telegram_bot_state");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).HasColumnName("id");
            entity.Property(x => x.NextUpdateId).HasColumnName("next_update_id");
        });

        modelBuilder.Entity<Nomenclature>(entity =>
        {
            entity.ToTable("nomenclatures");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.WbNomenclatureId).IsRequired().HasMaxLength(50).HasColumnName("wb_nomenclature_id");
            entity.Property(e => e.Name).IsRequired().HasMaxLength(1000).HasColumnName("name");
            entity.Property(e => e.StoreId).HasColumnName("store_id");
            entity.HasOne(e => e.Store)
                .WithMany()
                .HasForeignKey(e => e.StoreId)
                .HasConstraintName("FK_nomenclatures_stores_store_id")
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(e => new { e.StoreId, e.WbNomenclatureId }).IsUnique();
        });

        modelBuilder.Entity<CampaignNomenclatureStatistics>(entity =>
        {
            entity.ToTable("campaign_nomenclature_statistics");
            entity.HasKey(e => new { e.CampaignId, e.NomenclatureId, e.Date });
            entity.Property(e => e.CampaignId).HasColumnName("campaign_id");
            entity.Property(e => e.NomenclatureId).HasColumnName("nomenclature_id");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.Spend).HasColumnName("spend").HasColumnType("decimal(18,2)");
            entity.Property(e => e.Revenue).HasColumnName("revenue").HasColumnType("decimal(18,2)");
            entity.Property(e => e.Impressions).HasColumnName("impressions");
            entity.Property(e => e.Clicks).HasColumnName("clicks");
            entity.Property(e => e.Carts).HasColumnName("carts");
            entity.Property(e => e.Orders).HasColumnName("orders");
            entity.Property(e => e.OrderedProducts).HasColumnName("ordered_products");
            entity.Property(e => e.RecommendationFieldsVerified).HasColumnName("recommendation_fields_verified");
            entity.Property(e => e.Cancellations).HasColumnName("cancellations");
            entity.Property(e => e.Ctr).HasColumnName("ctr").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Cr).HasColumnName("cr").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Cpm).HasColumnName("cpm").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Cpc).HasColumnName("cpc").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Cpo).HasColumnName("cpo").HasColumnType("decimal(18,4)");
            entity.Property(e => e.AveragePosition).HasColumnName("average_position").HasColumnType("decimal(18,4)");
            entity.HasOne(e => e.Campaign).WithMany().HasForeignKey(e => e.CampaignId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(e => e.Nomenclature).WithMany().HasForeignKey(e => e.NomenclatureId).OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(e => new { e.NomenclatureId, e.Date });
        });

        modelBuilder.Entity<CampaignStatistics>(entity =>
        {
            entity.ToTable("campaign_statistics");
            entity.HasKey(e => new { e.CampaignId, e.Date });
            entity.Property(e => e.CampaignId).HasColumnName("campaign_id");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.Revenue).HasColumnName("revenue").HasColumnType("decimal(18,2)");
            entity.Property(e => e.Spend).HasColumnName("spend").HasColumnType("decimal(18,2)");
            entity.Property(e => e.Clicks).HasColumnName("clicks");
            entity.Property(e => e.Ctr).HasColumnName("ctr").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Drr).HasColumnName("drr").HasColumnType("decimal(18,4)");
            entity.Property(e => e.Impressions).HasColumnName("impressions");
            entity.Property(e => e.Carts).HasColumnName("carts");
            entity.Property(e => e.Orders).HasColumnName("orders");
            entity.Property(e => e.Cancellations).HasColumnName("cancellations");
            entity.HasOne<Campaign>().WithMany().HasForeignKey(e => e.CampaignId);
        });



    }
}
