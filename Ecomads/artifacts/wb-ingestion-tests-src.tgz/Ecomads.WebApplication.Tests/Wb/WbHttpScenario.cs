using System.Net;
using System.Text;

namespace Ecomads.WebApplication.Tests.Wb;

// Ordered HTTP responses: unexpected retries fail the test instead of returning an endless fixture.
internal sealed class WbHttpScenario : HttpMessageHandler
{
    private readonly Queue<Func<CancellationToken, Task<HttpResponseMessage>>> steps = new();
    public List<string> Requests { get; } = [];
    public WbHttpScenario Reply(string body, HttpStatusCode status = HttpStatusCode.OK, int? retryAfter = null)
    {
        steps.Enqueue(_ =>
        {
            var response = new HttpResponseMessage(status) { Content = new StringContent(body, Encoding.UTF8, "application/json") };
            if (retryAfter.HasValue) response.Headers.RetryAfter = new(TimeSpan.FromSeconds(retryAfter.Value));
            return Task.FromResult(response);
        });
        return this;
    }
    public WbHttpScenario Fail(Exception error)
    { steps.Enqueue(_ => Task.FromException<HttpResponseMessage>(error)); return this; }
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
    {
        Requests.Add(request.RequestUri!.PathAndQuery);
        if (steps.Count == 0) throw new InvalidOperationException("Неожиданный дополнительный запрос WB.");
        return steps.Dequeue()(ct);
    }
}

internal sealed class WbTestClock(DateTimeOffset now) : TimeProvider
{
    public DateTimeOffset Now { get; set; } = now;
    public override DateTimeOffset GetUtcNow() => Now;
}
