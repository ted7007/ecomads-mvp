using System.Text.Json;
using Ecomads.WebApplication.Data;
using Ecomads.WebApplication.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Ecomads.WebApplication.Services.Wb;

public sealed class WbCostsImporter(EcomadsDbContext db, TimeProvider? clock = null)
{
    public async Task<int> ImportAsync(Guid storeId, DateOnly start, DateOnly end, JsonElement root,
        CancellationToken ct, bool allowAdjacentDays = false, bool fillMissingOnly = false)
    {
        if (root.ValueKind != JsonValueKind.Array) throw new JsonException("История затрат WB не является массивом.");
        var context = WbIngestionContext.Current;
        var now = context?.RequestedAtUtc ?? (clock ?? TimeProvider.System).GetUtcNow().UtcDateTime;
        var quality = new WbQuality(db, clock);
        var totals = new Dictionary<DateOnly, decimal>();
        var counts = new Dictionary<DateOnly, int>();
        var badDates = new HashSet<DateOnly>();
        var unknownDate = false;
        var ordinal = 0;
        var imported = 0;
        foreach (var item in root.EnumerateArray())
        {
            var rawTime = item.ValueKind == JsonValueKind.Object && item.TryGetProperty("updTime", out var t) &&
                t.ValueKind == JsonValueKind.String ? t.GetString() : null;
            DateTime? instant = WbDates.TryInstant(rawTime, out var parsed) ? parsed : null;
            DateOnly? date = instant.HasValue ? WbDates.MoscowDay(instant.Value) : null;
            decimal? amount = item.ValueKind == JsonValueKind.Object && item.TryGetProperty("updSum", out var a) &&
                a.ValueKind == JsonValueKind.Number && a.TryGetDecimal(out var money) && money >= 0 ? money : null;
            var state = date == null ? "ambiguous_time" : amount == null ? "invalid_amount" :
                date < start.AddDays(-2) || date > end.AddDays(2) ? "unexpected_date" :
                date < start || date > end ? "adjacent" : "data";
            if (context?.SnapshotId is { } snapshotId)
            {
                var observation = await db.WbCostObservations.FindAsync([snapshotId, ordinal], ct);
                if (observation == null)
                {
                    observation = new() { SnapshotId = snapshotId, Ordinal = ordinal, StoreId = storeId };
                    db.WbCostObservations.Add(observation);
                }
                observation.RawJson = item.GetRawText(); observation.RawTime = rawTime;
                observation.OccurredAtUtc = instant; observation.MoscowDate = date;
                observation.Amount = amount; observation.State = state;
            }
            ordinal++;
            if (date == null) { unknownDate = true; continue; }
            if (state is "invalid_amount" or "unexpected_date") { badDates.Add(date.Value); unknownDate |= state == "unexpected_date"; continue; }
            totals[date.Value] = totals.GetValueOrDefault(date.Value) + amount!.Value;
            counts[date.Value] = counts.GetValueOrDefault(date.Value) + 1;
            if (date >= start && date <= end) imported++;
        }
        var existing = await db.WbStoreDailySpends.Where(x => x.StoreId == storeId && x.Date >= start && x.Date <= end)
            .ToDictionaryAsync(x => x.Date, ct);
        foreach (var outside in totals.Keys.Where(x => x < start || x > end))
            await quality.ObserveAsync(storeId, "expenses_boundary", "", outside, outside, "partial", ct,
                "Операции сохранены; этот ответ не покрывает соседний день целиком.", proposed: totals[outside]);
        for (var date = start; date <= end; date = date.AddDays(1))
        {
            existing.TryGetValue(date, out var old);
            if (fillMissingOnly && old != null) continue;
            var total = totals.GetValueOrDefault(date);
            // A neighbouring response may be the only time WB returned an operation.
            // Keep it as evidence; do not add overlapping snapshots together or call an
            // incomplete replacement a complete zero.
            var retainedBoundary = await db.WbSourceQualities.AsNoTracking().SingleOrDefaultAsync(x =>
                x.StoreId == storeId && x.Source == "expenses_boundary" && x.Entity == "" &&
                x.StartDate == date && x.EndDate == date, ct);
            var boundaryConflict = old == null && retainedBoundary?.ProposedValue > total;
            var state = unknownDate || badDates.Contains(date) || boundaryConflict ? "ambiguous" :
                old != null && total < old.Spend ? "revision" :
                !counts.ContainsKey(date) ? "no_operations" : total == 0 ? "zero" : "data";
            var reason = state switch {
                "ambiguous" => boundaryConflict ? "В соседнем ответе сохранены расходы, отсутствующие в новом снимке. Требуется сверка снимков." :
                    "В ответе есть операция с неоднозначной датой или суммой.",
                "revision" => !counts.ContainsKey(date) ? "В новой истории нет операций. Предлагаемый нулевой итог не подтверждает отсутствие расхода; прежняя сумма сохранена." :
                    "WB вернул меньший расход; требуется принять пересчёт.",
                "no_operations" => "В полученной истории нет операций. Это не явный ноль WB.", _ => null };
            if (!await quality.ObserveAsync(storeId, "expenses", "", date, date, state, ct, reason, old?.Spend, total)) continue;
            if (!WbQuality.Confirmed(state)) continue;
            if (old == null) { old = new() { StoreId = storeId, Date = date }; db.WbStoreDailySpends.Add(old); }
            old.Spend = total; old.LoadedAtUtc = now;
        }
        await db.SaveChangesAsync(ct);
        return imported;
    }
}
